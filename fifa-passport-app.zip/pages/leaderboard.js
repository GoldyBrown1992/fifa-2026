export default function LeaderboardPage() {
  return (
    <div className="min-h-screen bg-pastelgreen p-8">
      <h1 className="text-3xl font-bold mb-4">Leaderboard</h1>
      <p>Top explorers will be listed here with their stamp counts.</p>
    </div>
  );
}
