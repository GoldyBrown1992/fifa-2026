export default function MapPage() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-pastelyellow">
      <h1 className="text-3xl mb-4">Toronto Map (Pixel Art)</h1>
      <p>Interactive map will go here with clickable neighborhoods & venues.</p>
    </div>
  );
}
